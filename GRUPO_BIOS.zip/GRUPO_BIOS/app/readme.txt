GRUPO BIOS - PRUEBA TECNICA ANALISTA IA

DESCRIPCIÓN DE LA SOLUCIÓN:

Se realiza inicialmente una análisis para ver cual es el fin del modelo, se busca la implementación
de un RAG el cual obtenga un archivo (4 opciones) procese la información y así pueda dar respuesta
a preguntar orientadas sobree el tema.

Objetivo Alcanzado: Agregar documentos con exito y luego preguntarle al modelo sobre cosas relacionadas
al documento cargado. Se recibe respuesta sin alucionaciones y metodica sobre la pregunta.

ARQUITECTURA UTILIZADA:

- Aplicación Web (Sencilla) - Interacción de Usuario
- Fast API implementación de servidor local
- Metodo /cargar_documentos o /preguntar.
- Contexto de contenido y uso de embedding.
- Almancenamiento de Vectores.
- LLM genera respuestas.
- Fast API devuelve JSON.
- Usuario consume.

INSTRUCCIONES DE EJECUCION:

- Descomprimir el .zip
- Realizar pip install sobre los requirements.txt "pip install -r requirements.txt".(En CMD)
- Instalar el modelo de texto generativo ejecute en cmd "ollama run llama3"
- Desplegar el servidor local con Fast API, ejecutar en consola lo siguiente:  "uvicorn app.main:app --reload".
- Abrir la dirección "http://127.0.0.1:8000/" en el navegador.
- Elegir la acción que se desea realizar, tener en cuenta que si preguntamos sin alimentar nuestra base
  de conocimiento, no tendremos respuesta sobre algún tema.
- Si la acción es adjuntar documento hágalo y presione el botón "Cargar Archivo".
- Si la acción es preguntar al modelo hágalo y presione el botón "Preguntar".

DECISION TÉCNICAS TOMADAS:

- Se decide aplicar para el objetivo una aplicación web local, la cual sea intuitiva para los usuarios de uso
  aplicando tecnologías como Jquery, Boostrap y HTML. Fácil uso de acciones y metodos de envío.

- Se establece levantar el servidor con FAST API, y configurando la lectura y redirección correcta para nuestra
  página HTML.

- Para la implementación del RAG se decide usar langchain, ya que es un framework, que nos brinda la facilidad,
  de implementar modelos de embedding, vectorización de datos y modelos de texto generativo.

- Para el modelo de embedding se usa "all-mpnet-base-v2" ya que es un modelo facil de implementar,
  con una precisión buena sin sacrificar el procesamiento o tener dependencia de hardware.

- Para el modelo de texto generativo se realizaron varias pruebas:
  *Inicialmente se contempla usar la API de OpenAI, pero no se cuenta con creditos para dichos consumos.
  *Basado en lo anterior, se hacen pruebas con modelos de HUGGINFACE pero encontramos que al generar la respuesta
   el modelo alucinaba y entregaba todo el PROMPT que se le brindaba.
  *Finalmente se toma la decisión de utilizar OLLAMA como alternativa con su modelo de llama 3, ya que es
   un modelo con una cantidad de parametros considerables para que así nos ejecute bien la respuesta esperada,
   cabe aclarar que se depende de capacidad de procesamiento.

- Se trata de configurar OLLAMA para que ejecute basado en la GPU, pero el sistema operativo es Windows y
  el hardware es Intel ARC.

POSIBLES MEJORAS:

- Realizar un aplicativo con frameworks de desarrollo web, además de agregar mas funcionalidades (Login, Listado de transacciones, etc...)
- Almacenar nuesta base de conocimientos en un entorno especializado para ello, donde se pueda crear
  una Base de Datos vectorial.
- Cambiar el entorno de ejecución a Linux para que así se pueda contemplar mejor la capacidad de procesamiento.
- Desplegar en un entorno de producción donde toda persona de la organización pueda hacer uso de la herramienta.
