$(document).ready(function() {
    //Función de cambio para cuando se seleccione la opción que se desea realizar
    $('#que_hacer').change(function(){
        if($(this).val() == "1"){
            $("#form_cargar_doc").show();
            $("#form_preguntar").hide();
        }else{
            $("#form_cargar_doc").hide();
            $("#form_preguntar").show();
        }
    });
    //Función para cuando se envíe la pregunta ejecute su analisis
    $('#preguntar').click(function(e){
        //Obtenemos el formulario de acción
        var pregunta = $('#form_preguntar')[0]
        //Validamos si el campo está vacío o no
        if(pregunta.checkValidity()){
    
            e.preventDefault(); //Se realiza para que no haga el action por la url
            //Creamos el FormData que enviará los datos por la petición
            var formData = new FormData(document.getElementById("form_preguntar"));
            //Mensaje que nos indica que se está procesando la solicitud
            swal({
                title: 'Grupo BIOS',
                text: 'Analizando...',
                type: 'info',
                showConfirmButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false,
                onBeforeOpen: () => {
                    swal.showLoading();
                }
            });
            //Envía los datos por medio de FastAPI configurada
            $.ajax({
                url: "/preguntar",
                method: "POST",
                processData: false,
                contentType: false,
                data: formData,
                error: function (request, error) {
                    console.log(arguments);
                    alert('Ocurrió un error.');
                },
                success: function (response) {
                    if (response.success === true) {
                        swal({
                            title: 'Respuesta generada',
                            type: 'success'
                        }, function () {
                            $('#label_respuesta').show();
                            $('#respuesta').html(response.respuesta);                 
                        });
                    } else {
                        alert('Ocurrió un error')
                    }
                }
            });
        }else{
            //Reporta si el campo está vacío
            pregunta.reportValidity();
        }
    });
    //Función para cuando se envíe el documento
    $('#cargar').click(function(e){
        //Cargamos el formulario correspondiente
        var documento = $('#form_cargar_doc')[0]

        if(documento.checkValidity()){
            e.preventDefault();
            var formData = new FormData(document.getElementById("form_cargar_doc"));
            archivo = $('#archivo_adjunto')[0].files[0];
            formData.append('file',archivo);

            swal({
                title: 'Grupo BIOS',
                text: 'Cargando...',
                type: 'info',
                showConfirmButton: false,
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false,
                onBeforeOpen: () => {
                    swal.showLoading();
                }
            });

            $.ajax({
                url: "/cargar_doc",
                method: "POST",
                processData: false,
                contentType: false,
                data: formData,
                error: function (request, error) {
                    console.log(arguments);
                    alert('Ocurrió un error.');
                },
                success: function (response) {
                    console.log(response);
                    if (response.success === true) {
                        swal({
                            title: 'Documento cargado',
                            type: 'success'
                        }, function () {
                            location.reload();
                        });
                    } else {
                        alert('Ocurrió un error')
                    }
                }
            });
        }else{
            documento.reportValidity();
        }
    });

});
