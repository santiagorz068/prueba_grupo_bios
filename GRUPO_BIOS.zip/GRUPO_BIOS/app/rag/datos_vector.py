from langchain_chroma  import Chroma #Almacenamiento de Vector
from .embeddings import obtener_embeddings

def crear_vector(documento):

    embeddings = obtener_embeddings() #Obtenemos el formato de embeddings
    #Definimos Vectordb para que almacene nuestra información vectorizada en la ruta
    vectordb = Chroma.from_documents(
        documento,
        embeddings,
        persist_directory="app/data/vectores"
    )

    return vectordb

def cargar_vector():

    embeddings = obtener_embeddings()#Obtenemos el formato de embeddings
    #Cargamos los vectores creados
    vectordb = Chroma(
        persist_directory="app/data/vectores",
        embedding_function=embeddings
    )

    return vectordb