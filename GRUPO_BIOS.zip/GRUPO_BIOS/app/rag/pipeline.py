from langchain_classic.chains import RetrievalQA #Uso exclusivo de nuestra base de conocimiento
from langchain_ollama import OllamaLLM #Modelo o LLM usado para responder
from langchain_core.prompts import PromptTemplate #Plantilla para el Prompt de pregunta
from .datos_vector import cargar_vector

def preguntar_modelo(question):
    vectordb = cargar_vector() #Cargar la información vectorizada
    retriever = vectordb.as_retriever(
        search_kwargs={
            "k": 5,
            "fetch_k": 20  #Vectores considerar antes de filtrar
        },
        search_type="mmr",  #Activa Maximal Marginal Relevance (Metodo de selección)
        search_kwargs_mmr={"lambda_mult": 0.5}  #Balance relevancia/diversidad
    )

    # LLM usando Ollama
    llm = OllamaLLM(
        model="llama3",
        temperature=0.01 #Le configuramos la varianza al modelo
    )
    #Template del prompt donde damos especificaciones al modelo
    template = """
    Responde la pregunta usando SOLO el contexto proporcionado.

    Contexto:
    {context}

    Pregunta:
    {question}

    Si la respuesta no está en el contexto responde:
    "No se encontró información en el documento".
    """
    #Damos el formato de Prompt
    prompt = PromptTemplate(
        template=template,
        input_variables=["context", "question"]
    )

    qa = RetrievalQA.from_chain_type(
        llm=llm, #Modelo establecido
        retriever=retriever, #Busqueda de relevancia en nuestra Base de Conocimiento
        chain_type_kwargs={"prompt": prompt} #Se pasa el prompt personalizado
    )

    response = qa.invoke({"query": question}) #Envía la pregunta a nuestro Retrieval

    return response
