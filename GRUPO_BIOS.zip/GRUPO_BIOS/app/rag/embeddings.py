from langchain_community.embeddings import HuggingFaceEmbeddings #Modelo de embeddings

#Definimos la función con el modelo de sentencia para embeber la información
def obtener_embeddings():

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2"
    )
    return embeddings