from langchain_community.document_loaders import PyPDFLoader,TextLoader,UnstructuredWordDocumentLoader,UnstructuredExcelLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
import os

#Función de carga de documentos con condiciones de pendiendo el formato de archivo relacionado
def carga_documento(archivo):
    extension = os.path.splitext(archivo)[1].lower()

    if(extension == ".pdf"):
        loader = PyPDFLoader(archivo)
    elif(extension == ".docx"):
        loader = UnstructuredWordDocumentLoader(archivo)
    elif(extension == ".xlsx"):
        loader = UnstructuredExcelLoader(archivo)
    elif(extension == ".txt"):
        loader = TextLoader(archivo)
    else:
        return 'Formato de archivo no permitido'
    documents = loader.load()
    #Formato para fragmentar la información de los documentos
    splitter = RecursiveCharacterTextSplitter(
       chunk_size=800,       #tamaño ideal para numerico de tokens
       chunk_overlap=150,    #mantiene contexto entre chunks
    )
    #Creación de los lotes
    chunks = splitter.split_documents(documents)

    return chunks