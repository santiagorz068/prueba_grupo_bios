from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse #Librería de direccionamiento a pagina
from fastapi.staticfiles import StaticFiles #Procesamiento de archivos js
from fastapi.templating import Jinja2Templates #Procesamiento de archivos .html
import shutil
from .rag.carga_documentos import carga_documento
from .rag.datos_vector import crear_vector
from .rag.pipeline import preguntar_modelo
from pydantic import BaseModel

app = FastAPI()

#Montamos la carpeta para los archivos .js
app.mount("/assets", StaticFiles(directory="app/assets"), name="assets")
#Montamos la ruta en Jinja para el template de html
templates = Jinja2Templates(directory="app/templates")

#Obtenemos la dirección por defecto del localhost y redireccionamos al index.html
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )

#Creamos la petición de cargar documentos - Metodó POST
@app.post("/cargar_doc")
async def cargar_doc(file: UploadFile):
    print(file) #Recibimos en función asyncrona el archivo
    path = f"app/data/documentos/{file.filename}"#Indicamos que lo almacene en la ruta

    #Guardamos en disco el archivo recién subido, para manejarlo como objeto binario
    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    docs = carga_documento(path) #Asignamos en la variable la función de carga de documentos

    crear_vector(docs) #Ejecutamos la función de crear el vector

    return {"success": True} #Retornamos success, para validar que todo salió bien

#Creamos la petición de preguntar - Metodó POST
@app.post("/preguntar")
def preguntar(pregunta: str = Form(...)):
    #Se define que lo que venga por medio de FORM es string
    response = preguntar_modelo(pregunta)#Preguntamos la modelo
    #Retornamos mensaje de confirmación y la respuesta del modelo
    return {"success": True, "respuesta": response['result']}